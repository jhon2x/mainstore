var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Emarsys_Emarsys/js/model/shipping-save-processor/default'
        }
    }
};
