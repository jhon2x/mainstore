<?php
/**
 * @category   Emarsys
 * @package    Emarsys_Emarsys
 * @copyright  Copyright (c) 2017 Emarsys. (http://www.emarsys.net/)
 */
namespace Emarsys\Emarsys\Logger;

/**
 * Class Logger
 * @package Emarsys\Emarsys\Logger
 */
class Logger extends \Monolog\Logger
{
}