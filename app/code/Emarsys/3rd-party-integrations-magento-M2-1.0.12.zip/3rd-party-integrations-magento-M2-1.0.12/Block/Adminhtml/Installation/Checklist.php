<?php
/**
 * Copyright © 2015 Yagendra . All rights reserved.
 */
namespace Emarsys\Emarsys\Block\Adminhtml\Installation;

/**
 * Class Checklist
 * @package Emarsys\Emarsys\Block\Adminhtml\Installation
 */
class Checklist extends \Magento\Backend\Block\Template
{
    function _prepareLayout()
    {
    }
}
