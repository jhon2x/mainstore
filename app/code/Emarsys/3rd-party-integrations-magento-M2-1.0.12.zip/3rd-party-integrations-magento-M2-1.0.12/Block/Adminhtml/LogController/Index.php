<?php
/**
 * @category   Emarsys
 * @package    Emarsys_Emarsys
 * @copyright  Copyright (c) 2017 Emarsys. (http://www.emarsys.net/)
 */
namespace Emarsys\Emarsys\Block\Adminhtml\LogController;

/**
 * Class Index
 * @package Emarsys\Emarsys\Block\Adminhtml\LogController
 */
class Index extends \Magento\Backend\Block\Template
{

}
